duong = lambda n: n > 0

print(duong(2))
print(duong(-6))