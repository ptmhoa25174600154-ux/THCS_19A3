
def giai_pt(a, b):
    if a == 0:
        if b == 0:
            return "Vô số nghiệm"
        else:
            return "Vô nghiệm"
    else:
        return -b / a
print(giai_pt(2, 4))
print(giai_pt(0, 0))
print(giai_pt(0, 5))

