def so_armstrong(n):
    chuoi = str(n)
    so_chu_so = len(chuoi)
    tong = 0
    for c in chuoi:
        tong += int(c) ** so_chu_so
    return tong == n
print(so_armstrong(153))
print(so_armstrong(123))