
def chuyen_doi(do_c):
    return do_c * 9/5 + 32
print(chuyen_doi(25))

