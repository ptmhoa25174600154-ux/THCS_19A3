chan = lambda n: n % 2 == 0

print(chan(4))
print(chan(5))