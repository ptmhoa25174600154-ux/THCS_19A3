tich = lambda a, b, c: a * b * c

print(tich(1, 3, 4))