def doi_xung(n):
    n = str(n)
    return n == n[::-1]
print(doi_xung(121))
print(doi_xung(122))