def so_nt(n):
    if n < 2:
        return False
    for i in range(2, n):
        if n % i == 0:
            return False
    return True
print("Các số nguyên tố từ 100 đến 500:")