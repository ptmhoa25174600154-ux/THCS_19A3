def tbc(a, b, c):
    return (a + b + c) / 3
# Thử
print(tbc(22, 23, 24))