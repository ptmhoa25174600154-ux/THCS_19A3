tong = lambda a, b: a + b

print(tong(5, 10))