def le_lon_nhat(a, b, c):
    ds = []
    for x in [a, b, c]:
        if x % 2 != 0:
            ds.append(x)
    if len(ds) == 0:
        return "Không có số lẻ"
    return max(ds)
print(le_lon_nhat(20, 24, 26))
print(le_lon_nhat(11, 33, 10))