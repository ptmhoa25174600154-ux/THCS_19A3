def hoan_hao(n):
    tong = 0
    for i in range(1, n):
        if n % i == 0:
            tong += i
    return tong == n


def tong_hoan_hao(a, b):
    tong = 0
    for i in range(a, b+1):
        if hoan_hao(i):
            tong += i
    return tong
print(tong_hoan_hao(2, 100))