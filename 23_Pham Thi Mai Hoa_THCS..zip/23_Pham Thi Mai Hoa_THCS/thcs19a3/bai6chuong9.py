def nguyen_to(n):
    if n < 2:
        return False
    for i in range(2, n):
        if n % i == 0:
            return False
    return True

def nguyen_to_khoang(a, b):
    ds = []
    for i in range(a, b+1):
        if nguyen_to(i):
            ds.append(i)
    return ds
print(nguyen_to_khoang(1, 20))